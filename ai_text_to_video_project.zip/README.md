
# AI Text to Video Generator

## Steps to Run the Project:

1. **Get a Pexels API Key**:
   - Go to [Pexels API](https://www.pexels.com/api/) and sign up for a free account.
   - Get your API key and replace `YOUR_PEXELS_API_KEY` in the `index.html` file.

2. **Get a ResponsiveVoice API Key** (optional):
   - Go to [ResponsiveVoice](https://responsivevoice.org/) to get an API key.
   - Replace `YOUR_KEY_HERE` in the `index.html` file.

3. **Open Locally**:
   - Download the folder and open `index.html` in your browser.
   - Enter any text, click "Generate", and the video (images + speech) will be generated!

## Customize
Feel free to tweak the code, replace APIs, or add more features as needed.

Good luck and have fun with your project!
